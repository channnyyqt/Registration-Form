class Student {
  constructor(firstname, middlename, lastname, suffix, contact, email, course, batch, id) {
    this.firstname = firstname;
    this.middlename = middlename;
    this.lastname = lastname;
    this.suffix = suffix;
    this.contact = contact;
    this.email = email;
    this.course = course;
    this.batch = batch;
    this.id = id;
  }
}
